</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <link href="UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="stylecss.css" rel="stylesheet" type="text/css">

</head>

<body class="v-details-color">
    <div class="uk-container-extend" uk-animation="animation: uk-animation-fade">
        <div class="nav-container">
            <p class="user-type">Department Head</p>
            <p class="user-type">Jason Guzman </p>
            <p class="user-type">July 19, 2018| 4:00pm</p>
            <p class="dept-desc">HR DEPARTMENT</p>
        </div>

        <div class="form-container uk-container-medium uk-position-top">
            <div class="job-title">
                <p>Job Order Title Here</p>
            </div>
            <form class="view-control">
                <div>
                    <b>Job Order #:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div>
                    <b>Requested By:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div>
                    <b>Requested To:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div>
                    <b>Date Requested:</b>
                    <input class="uk-input view-input" type="date" readonly>
                </div>
                <div class="v-desc">
                    <b>Description:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div class="acknow">
                    <b>Acknowledged By:</b>
                    <input class="uk-input view-input-ackno" type="text" readonly>
                    <!--<input class="uk-input view-input" type="date" readonly>-->
                    <p class="ackno-date"> July 19, 2018| 2:00PM</p>
                </div>

                <div class="apprv">
                    <b>Approved:</b>
                    <select class="select-control" name="acknowledge">
                        <option value selected>Yes/No...</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </div>
                <div class="v-buttons">
                    <button class="view-button" type="submit">Back</button>
                    <button class="view-button-up" type="button"><a href="#">Update</a></button>
                </div>
            </form>
        </div>
    </div>
    <script src="Jquery/jquery-1.10.2.min.js"></script>
    <script src="Jquery/jquery.min.js"></script>
    <script src="UIKIT/js/uikit.js"></script>
    <script src="UIKIT/js/uikit-icons.js"></script>


</body>

</html>