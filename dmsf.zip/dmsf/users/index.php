<?php 
    require("../includes/db_connection.php");
    include("../includes/functions.php");
    include("../includes/session.php");
    
    global $logged_in_user;
    global $logged_in_user_type;
    global $logged_in_user_dept;
    global $logged_init;
    global $logged_deptcode;


    
?>

</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="../css/stylecss-new.css" rel="stylesheet" type="text/css">

</head>

<body>
    <div class="uk-container-extend">

        <!-- Navigation Bar -->
        <?php include("../includes/nav-bar.php"); ?>

        <div class="second-nav-container">
            <a href="Request-Form.php" class="uk-button request-button"><span class="plus-icon" uk-icon="icon:plus"></span>NEW REQUEST</a>
            <div class="uk-form-select" data-uk-form-select>
                <select class="uk-form-control search-by" id="requested_to" name="todept">
                                    <option value selected>Search by...</option>
                                    <option value="002">Job Order #</option>
                                    <option value="001">Request By:</option>
                                    <option value="001">Request To:</option>
                                    <option value="001">Job Order Title</option>
                                    <option value="001">Job Order Date</option>
                                    <option value="001">Status</option>
                                    </select>
                <button class="search-button" value="Search" name="search" type="submit">SEARCH</button>
            </div>
        </div>
        <div class="uk-container-expand body-container">
            <div class="table-control uk-margin">
                <form class="uk-form" action="#" method="POST">
                </form>
                <ul class="uk-subnav tab-list uk-subnav-pill" style="margin-bottom: 0px;" uk-switcher="animation: uk-animation-fade">
                    <li><a href="#">All Requests</a></li>
                    <li><a href="#">Pending Requests</a></li>
                    <li><a href="#">Approved Requests</a></li>
                </ul>
                <ul class="uk-switcher">
                    <li>
                        <div class="table-class table-container">
                            <table class="uk-table request-table uk-table-responsive">
                                <thead class="req-thead">
                                    <tr>
                                        <th>JOB ORDER #</th>
                                        <th>JOB ORDER DATE</th>
                                        <th>REQUESTED TO:</th>
                                        <th>JOB ORDER TITLE</th>
                                        <th>REQUESTED BY:</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>

                                <tbody class="req-td">
                                    <?php
                                    if(isset($_POST['search'])) {
                                        date_range($logged_deptcode);
                                    }else{
                                        //display table data
                                        $query = "select * from joHeader WHERE reqdept = '$logged_deptcode' ORDER BY jodate DESC";
                                        $result = mysqli_query($connection, $query);
                                        if(!$result) {
                                            die("Database query failed.");
                                        }
                                        
                                        
                                        while($row=mysqli_fetch_assoc($result)){
                                            $jor_num = $row['jo_num'];
                                            $requested_by = $row['reqby'];
                                            $dept_name = $row['reqdept'];
                                            $requested_to = $row['todept'];
                                            $jor_title = $row['jotitle'];
                                            $jor_description = $row['jorem'];
                                            $order_date = $row['jodate'];
                                                  
                                            $date = date_create($order_date);
                                            $fname = get_user($requested_by);
                                            $dept = get_dept($requested_to);

                                            echo" 
                                            <tr> 
                                                <td>".$jor_num."</td>
                                                <td>".date_format($date, "F d, Y / g:ia")."</td>
                                                <td>".$dept."</td>
                                                <td class=\"uk-text-truncate\">".$jor_title."</td>
                                                <td>".$fname."</td>
                                                <td><a href=\"view-details-AllPage.php?id=$jor_num\"><button type=\"button\" class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                                                </tr>";
                                        }
                                     }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </li>
                    <li>
                        <div class="table-class table-container">
                            <table class="uk-table request-table uk-table-responsive">
                                <thead class="req-thead">
                                    <tr>
                                        <th>JOB ORDER #</th>
                                        <th>JOB ORDER DATE</th>
                                        <th>REQUESTED TO:</th>
                                        <th>JOB ORDER TITLE</th>
                                        <th>REQUESTED BY:</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody class="req-td">
                                    <?php
                                        if($logged_in_user_type == 'Staff'){
                                            staff_pending();
                                        }elseif($logged_in_user_type == 'Unit Head'){
                                            unithead_pending();
                                        }elseif($logged_in_user_type == 'Department Head'){
                                            depthead_pending();
                                        }else{
                                            echo "Invalid user!";
                                        }

                                ?>

                                </tbody>
                            </table>
                        </div>
                    </li>
                    <li>
                        <div class="table-class table-container">
                            <table class="uk-table request-table uk-table-responsive">
                                <thead class="req-thead">
                                    <tr>
                                        <th>JOB ORDER #</th>
                                        <th>JO DATE</th>
                                        <th>REQUEST TO:</th>
                                        <th>JOB ORDER TITLE</th>
                                        <th>REQUEST BY:</th>
                                        <th>APPROVED DATE</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody class="req-td">
                                    <?php
                                    if($logged_in_user_type == 'Staff'){
                                        staff_approved();
                                    }elseif($logged_in_user_type == 'Unit Head'){
                                        unithead_approved();
                                    }elseif($logged_in_user_type == 'Department Head'){
                                        depthead_approved();
                                    }else{
                                        echo "Invalid user!";
                                    }
                                ?>

                                </tbody>
                            </table>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
        <script src="../css/Jquery/jquery-1.10.2.min.js"></script>
        <script src="../css/Jquery/jquery.min.js"></script>
        <script src="../css/UIKIT/js/uikit.js"></script>
        <script src="../css/UIKIT/js/uikit-icons.js"></script>



</body>

</html>



<!--
    select * from request_form LEFT JOIN approved_tbl ON request_form.jor_num = approved_tbl.jor_num) WHERE request_form.status = 'approved';
-->
