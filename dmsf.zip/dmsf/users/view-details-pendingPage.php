<?php include("../includes/session.php"); ?>
</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="../css/stylecss-new.css" rel="stylesheet" type="text/css">

</head>

<body class="v-details-color">
    <div class="uk-container-extend" uk-animation="animation: uk-animation-fade">
        <?php include("../includes/nav-bar.php"); ?>

        <div class="form-container uk-container-medium uk-position-top">
            <div class="job-title">
                <p>Job Order Title Here</p>
            </div>
            <form class="view-control">
                <div>
                    <b>Job Order #:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div>
                    <b>Requested By:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div>
                    <b>Requested To:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
                <div>
                    <b>Date Requested:</b>
                    <input class="uk-input view-input" type="date" readonly>
                </div>
                <div class="v-desc">
                    <b>Description:</b>
                    <input class="uk-input view-input" type="text" readonly>
                </div>
<!--
                <div class="acknowledge">
                    <b>Acknowledge:</b>
                    <select class="select-control" name="select-ackno">
                        <option value selected>Yes/No...</option>
                        <option value="yes">Yes</option>
                        <option value="yes">No</option>
                    </select>
                </div>
-->
                <div>
                    <b>Action:</b>
                    <select class="select-control" type="text" name="acknowledge">
                        <option value selected></option>
                        <option value="yes">Acknowledge</option>
                        <option value="no">Approve</option>
                        <option value="no">Disapprove</option>
                    </select>
                </div>
                <div class="v-buttons">
                    <button class="view-button-up" type="button"><a href="#">Update</a></button>
                    <button class="view-button" type="submit"><a href="index.php">Back</a></button>
                </div>
            </form>
        </div>
    </div>
    <script src="../css/Jquery/jquery-1.10.2.min.js"></script>
    <script src="../css/Jquery/jquery.min.js"></script>
    <script src="../css/UIKIT/js/uikit.js"></script>
    <script src="../css/UIKIT/js/uikit-icons.js"></script>


</body>

</html>