<?php
    session_start();
     // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    
    $dt = date("Y-m-d H:i:s", time());
    
    $logged_in_user = $_SESSION["fname"];
    $logged_in_user_type = $_SESSION["usertype"];
    $logged_in_user_dept = $_SESSION["deptname"];
    $logged_init = $_SESSION["init"];
    $logged_deptcode = $_SESSION["deptcode"];

?>
    </!DOCTYPE html>
    <html>

    <head>
        <title>Job Order System
        </title>
        <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
        <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
        <link href="../css/stylecss-new.css" rel="stylesheet" type="text/css">
        <META NAME="DESCRIPTION" CONTENT="DEMO of passing user entered data on submit to main page using Jquery  ">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
        </META>

    </head>

    <body class="v-details-color">
        <div class="uk-container-extend" uk-animation="animation: uk-animation-fade">
            <?php include("../includes/nav-bar.php"); ?>

            <div class="form-container uk-container-medium uk-position-top">
                <div class="job-title">
                    <p>REQUEST FORM</p>
                </div>
                <form class="view-control">
                    <div class="date-marg">
                        <b>Date:</b>
                        <b><?php echo date_format($today, "F d, Y | h:ia");?></b>
                    </div>
                    <div>
                        <b>Request To:</b>
                        <select id="todept" name="todept" class="select-control" name="select-ackno">
                        <option value selected> </option>
                        <option value="001">ISDU</option>
                        <option value="002">ENGINEERING</option>
                    </select>
                    </div>
                    <div>
                        <b>Job Order Title:</b>
                        <!--<input id="jotitle" name="jotitle" class="uk-input view-input" type="text" required>-->
                        <textarea class="textarea-jortitle" rows="2" id="jotitle" name="jotitle" required></textarea>
                    </div>
                    <div class="v-desc">
                        <b class="text-desc">Description:</b>
                        <textarea class="textare" rows="6" id="jorem" name="jorem" required></textarea>
                    </div>
                    <div class="v-buttons-req">
                        <button id="b1" class="view-button-up" type="button">SUBMIT</button>
                        <a href="index.php"><button class="view-button" type="button">Back</button></a>
                    </div>
                </form>
            </div>
            
            <div id="body"></div>
            
            <div id="my_dialog">
                <form id=f1>
                    <input type=username id=t1 name=t1 placeholder="Username">
                    <input type=password id=t2 name=t2 placeholder="Password">
                </form>
            </div>
            
        </div>

        <script>
            $(document).ready(function() {
                $(function() {
                    var myPos = {
                        my: "center center",
                        at: "center center",
                        of: window
                    };
                    $("#my_dialog").dialog({
                        autoOpen: false,
                        draggable: false,
                        modal: true,
                        position: myPos,
                        buttons: {
                            "Submit ": function() {
                                $('#body').text('Wait..');
                                var t1 = $('#t1').val();
                                var t2 = $('#t2').val();
                                var todept = $('#todept').val();
                                var jotitle = $('#jotitle').val();
                                var jorem = $('#jorem').val();
                                $('#body').load("../includes/data.php?username=" + encodeURIComponent(t1) + "&&password=" + encodeURIComponent(t2) + "&&todept=" + encodeURIComponent(todept) + "&&jotitle=" + encodeURIComponent(jotitle) + "&&jorem=" + encodeURIComponent(jorem));
                                $(this).dialog("close");
                                // window.location = "index.php";
                                setTimeout(function() { window.location = "index.php"; }, 25);
                            },
                            "Close ": function() {
                                $(this).dialog("close");
                            }

                        }
                    });
                });


            $("#b1").click(function() {
                if ($.trim($('#todept').val()) == '' || $.trim($('#jotitle').val()) == '' || $.trim($('#jorem').val()) == '') {
                        alert('Input can not be left blank');
                    } else {
                        $("#my_dialog").dialog("open");

                    }

                })
            })
        </script>
        <script src="../css/textarea.js"></script>



    </body>

    </html>