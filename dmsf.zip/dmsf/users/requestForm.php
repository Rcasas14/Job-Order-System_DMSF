<?php
    include("../includes/session.php");
     // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    
    $dt = date("Y-m-d H:i:s", time());
    
    global $logged_in_user;
    global $logged_in_user_type;
    global $logged_in_user_dept;
    global $logged_init;
    global $logged_deptcode;

?>
    </!DOCTYPE html>
    <html>

    <head>
        <title>Job Order System
        </title>
        <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
        <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
        <link href="../css/stylecss.css" rel="stylesheet" type="text/css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>

    </head>


    <body>

        <div class="uk-container uk-animation-fade">
            <div class="request-form uk-card uk-card-default uk-position-center uk-form form-style">
                <div class="form-title">
                    <h2 class="uk-modal-title">REQUEST FORM</h2>
                </div>
                <div class="date">
                    <span>
                        Date: 
                        <b><?php echo date_format($today, "F d, Y | h:ia");?></b>
                    </span>
                </div>
                <p>
                    <div class="uk-form-select" data-uk-form-select>
                        <span class="name">Name: </span>
                        <b><?php echo $logged_in_user; ?></b>
                    </div>
                </p>
                <p>
                    <div class="uk-form-select" data-uk-form-select>
                        <span class="depart">Department: </span>
                        <b><?php echo $logged_in_user_dept; ?></b>
                    </div>
                </p>
                <p>
                    <div class="uk-form-select" data-uk-form-select>
                        <span class="to-req">Request To:</span>
                        <select id="todept" name="todept" class="uk-form-control">
                            <option value selected></option>
                            <option value="002">Engineering</option>
                            <option value="001">ISDU</option>
                        </select>
                    </div>
                </p>
                <p class="job-order-title">
                    <div class="uk-form-select" data-uk-form-select>
                        <span class="job-title">JOB ORDER TITLE: </span>
                        <input type="text" id="jotitle" name="jotitle" required>
                    </div>
                </p>
                <span>Description Of The Problem:</span>
                <textarea class="uk-textarea" rows="6" id="jorem" name="jorem" required></textarea>
                <p class="uk-text-right">
                    <button id="b1" class="uk-button submit-login">Submit</button>
                    <a class="uk-button submit-login uk-button-default" href="index.php">Back</a>
                </p>


                <div id=body></div>
                <div id=msg></div>

                <div id="my_dialog">
                    <form id=f1>
                        <input type=username id=t1 name=t1 placeholder="Username">
                        <input type=password id=t2 name=t2 placeholder="Password">
                    </form>
                </div>

                <div id='modal_dialog'>
                    <div class='title'></div>

                </div>
            </div>
        </div>


            <script>
                $(document).ready(function() {
                    $(function() {
                        var myPos = {
                            my: "center center",
                            at: "center center",
                            of: window
                        };
                        $("#my_dialog").dialog({
                            autoOpen: false,
                            draggable: false,
                            modal: true,
                            position: myPos,
                            buttons: {
                                "Submit ": function() {
                                    $('#body').text('Wait..');
                                    var t1 = $('#t1').val();
                                    var t2 = $('#t2').val();
                                    var todept = $('#todept').val();
                                    var jotitle = $('#jotitle').val();
                                    var jorem = $('#jorem').val();
                                    $('#body').load("../includes/data.php?username=" + encodeURIComponent(t1) + "&&password=" + encodeURIComponent(t2) + "&&todept=" + encodeURIComponent(todept) + "&&jotitle=" + encodeURIComponent(jotitle) + "&&jorem=" + encodeURIComponent(jorem));
                                    $(this).dialog("close");


                                    // window.location = "index.php";
                                    setTimeout(function() { window.location = "index.php"; }, 25);
                                },
                                "Close ": function() {
                                    $(this).dialog("close");
                                }

                            }
                        });
                    });


                    $("#b1").click(function() {
                        if ($.trim($('#todept').val()) == '' || $.trim($('#jotitle').val()) == '' || $.trim($('#jorem').val()) == '') {
                            alert('Input can not be left blank');
                        } else {
                            $("#my_dialog").dialog("open");

                        }

                    })
                })

            </script>


    </body>

    </html>
    <!-- $('#body').text('todept=' +$('#todept').val() + '&' + 'jotitle=' + $('#jotitle').val() + '&' + 'jorem=' + $('#jorem').val()); -->
    <!-- $('#body').text($('#todept').val() + $('#jotitle').val() + $('#jorem').val()); -->
    <!-- $('#msg').html($("#f1").serialize()); -->
