<?php 
    session_start();
    require("../../includes/db_connection.php");
    // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:i:s", time());
    $today = date_create($det);

    //display table data
    $query = "select * from request_form";
    $result = mysqli_query($connection, $query);
    if(!$result) {
      die("Database query failed.");
    }
    
    $logged_in_user = $_SESSION["uhead_username"];
    $logged_in_user_type = $_SESSION["uhead_usertype"];
    $logged_in_user_dept = $_SESSION["uhead_deptname"];



?>



	</!DOCTYPE html>
	<html>

	<head>
		<title>Job Order System
		</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../../css/assets/css/bootstrap.css" rel="stylesheet" />
		<link href="../../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
		<link href="../../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
		<link href="../../css/stylecss.css" rel="stylesheet" type="text/css">
	</head>

	<body class="ind-body">


		<div class="uk-container uk-animation-fade">

			<div class="request-list uk-card uk-card-default ">
				<nav class="uk-navbar-container top-section uk-navbar">
					<div class="uk-navbar-left">
						<ul class="uk-navbar-nav">
							<li class="uk-active">
								<a href="#">
									<?php echo $logged_in_user_dept; ?>
								</a>
							</li>
						
						</ul>
						<div class="uk-navbar-right">
							<ul class="uk-navbar-nav">
								<li class="uk-active">
									<a href="#">
										<?php echo $logged_in_user; ?>
									</a>
								</li>
								<li class="uk-active">
									<a href="#">
										<?php echo $logged_in_user_type; ?>
									</a>
								</li>
							</ul>
						</div>
					</div>

				</nav>
				<div class="uk-margin below-top-section">
					<form class="uk-form" action="../../includes/config.php" method="POST">
						<input class="uk-button search-button uk-button-default" value="Search" name="search" type="submit"></input>
						<input class="uk-input uk-form-small date-sort" type="date" name="date_to">
						<input class="uk-input uk-form-small date-sort" type="date" name="date_from">
					</form>
					<a class="uk-button uk-button-default uk-default request-button" href="../requestForm.php">NEW REQUEST</a>
					<br>
				</div>
				<div class="uk-margin table-container">
					<ul class="uk-tab uk-tab-flip" data-uk-tab="{connect:'#my-id'}">
						<li><a href="#">All List</a></li>
						<li><a href="#">Pending List</a></li>
						<li><a href="#">Approved List</a></li>
					</ul>
					<ul class="uk-switcher uk-margin">
						<li>
							<table class="uk-table request-table">
								<div class="tt">
									<thead class="req-thead">
										<tr>
											<tr>
												<th>JOB ORDER #</th>
												<th>REQUESTED BY:</th>
												<th>REQUESTED TO:</th>
												<th>JOB ORDER TITLE</th>
												<th>JOB ORDER DATE</th>
												<th>STATUS</th>
											</tr>
								</div>
								</thead>

								<tbody class="req-td">
									<?php
                                        while($row=mysqli_fetch_assoc($result)){
                                            $jor_num = $row['jor_num'];
                                            $requested_by = $row['requested_by'];
                                            $dept_name = $row['dept_name'];
                                            $requested_to = $row['requested_to'];
                                            $jor_title = $row['jor_title'];
                                            $jor_description = $row['jor_description'];
                                            $order_date = $row['order_date'];
                                            $status = $row['status'];
                                                  
                                            $date = date_create($order_date);

                                            echo"<tr>
                                                <td>".$jor_num."</td>
                                                <td>".$requested_by."</td>
                                                <td>".$requested_to."</td>
                                                <td>".$jor_title."</td>
                                                <td>".date_format($date, "F d, Y / g:ia")."</td>
                                                <td>".$status."</td>
                                                
                                                </tr>";
                                                  
                                            }
                                    ?>
								</tbody>
							</table>
						</li>
					</ul>
				</div>
			</div>
		</div>


		</div>

		<script src="../../css/Jquery/jquery-1.10.2.min.js"></script>
		<script src="../../css/Jquery/jquery.min.js"></script>
		<script src="../../css/UIKIT/js/uikit.js"></script>
		<script src="../../css/vendor/jquery/jquery.min.js"></script>
		<script src="../../css/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


	</body>

	</html>