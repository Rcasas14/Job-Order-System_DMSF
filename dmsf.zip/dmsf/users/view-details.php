<?php 
    require("../includes/db_connection.php");
    include("../includes/functions.php");
    include("../includes/session.php");
    
    global $logged_in_user_type;
    global $connection;
    global $d;
    $jor_num = mysqli_real_escape_string($connection, $_GET['id']);
    $query = "SELECT * FROM joHeader WHERE jo_num = '$jor_num' LIMIT 1";
    $results = mysqli_query($connection, $query);
    $data = mysqli_fetch_assoc($results);

    $fname = get_user($data['reqby']);
    $dept = get_dept($data['todept']);
    
?>
</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="../css/stylecss-new.css" rel="stylesheet" type="text/css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>

</head>

<body>
        <?php include("../includes/nav-bar.php"); ?>
    <div class="uk-container-extend" uk-animation="animation: uk-animation-fade">
        <div class="form-container uk-container-medium uk-position-top">
            <div class="job-title">
                <p>Job Order # <?php echo $data['jo_num']; ?></p>
            </div>
            <div class="view-control">
                <?php 
                    $date = date_create($data['jodate']);
                    $d = date_format($date, "F d, Y | g:ia");
                ?>
                <div>
                    <b>Date Requested:</b>
                    <input class="uk-input view-input" type="text" value="<?php echo $d; ?>" readonly>
                </div>
                <div>
                    <b>Title:</b>
                    <input class="uk-input view-input" type="text" value="<?php echo $data['jotitle']; ?>" readonly>
                </div>
                <div class="">
                    <b>Description:</b>
                    <input class="uk-input view-input" type="text" value="<?php echo $data['jorem']; ?>" readonly>
                </div>
                <div>
                    <b>Requested By:</b>
                    <input class="uk-input view-input" type="text" value="<?php echo $fname; ?>" readonly>
                </div>
                
                <!--       if else ka diri         -->
                <div>
                    <b>Action:</b>
                    <select class="select-control" type="text" id="action" name="action">
                        <option value selected></option>
                        <!--<option value="1">Acknowledge</option>-->
                        <option value="2">Approve</option>
                        <option value="3">Disapprove</option>
                    </select>
                </div>
                <!--                -->
                
                <div class="v-buttons">
                    <button id="b1" class="view-button-up" value="<?php echo $jor_num; ?>">Save</button>
                    <a href="index.php"><button class="view-button" type="submit">Back</button></a>
                </div>
                </div>
            </div>
        </div> 

        <div id="my_dialog">
            <form id=f1>
                <input type=username id=t1 name=t1 placeholder="Username">
                <input type=password id=t2 name=t2 placeholder="Password">
            </form>
        </div>
    
    <div id="body"></div>

<!--
        <div id="alert_msg">
            <div class='title'></div>
            <input type='button' value='yes' id='btnYes' />
            <input type='button' value='no' id='btnNo' />
        </div>
-->

        <script>
            $(document).ready(function() {
                $(function() {
                    var myPos = { my: "center center", at: "center center", of: window };
                    $( "#my_dialog" ).dialog({
                        autoOpen: false,
                        draggable: false,
                        modal: true,
                        position: myPos,
                        buttons: {
                            "Submit ": function(){
                                $('#body').text('Wait..');
                                var t1=$('#t1').val();
                                var t2=$('#t2').val();
                                var id=$('#b1').val();
                                var action=$('#action').val();
                                $('#body').load("../includes/config.php?id="+encodeURIComponent(id)+"&&username="+encodeURIComponent(t1)+"&&password="+encodeURIComponent(t2)+"&&action="+action);
                                $( this ).dialog( "close" );
                                //window.location = "index.php";
                                setTimeout(function() { window.location = "index.php"; }, 20);
                            },
                            "Close ": function() {
                                $( this ).dialog( "close" );
                            }
                            
                        }
                    });
                });         

                         
           
//            $("#b1").click(function(){
//                dialog('Are you sure?',
//                    function() {
//                        $( "#my_dialog" ).dialog( "open" );
//                        console.log("yes");
//                    },
//
//                    function() {
//                        console.log("no");
//                    }
//
//                ); 
//                })
//                        
//            })
//                $("#b1").click(function(){
//                    $( "#my_dialog" ).dialog( "open" );
//                    })
//                })
                
            $("#b1").click(function() {
                if ($.trim($('#action').val()) == '') {
                        alert('Input can not be left blank');
                    } else {
                        $("#my_dialog").dialog("open");

                    }

                })
            })
                


//            function dialog(message) {
//                $('.title').html(message);
//                    var dialog = $('#alert_msg').dialog();
//
//                    $('#btnYes').click(function() {
//                        dialog.dialog('close');
//                        yesCallback();
//                    });
//
//                    $('#btnNo').click(function() {
//                        dialog.dialog('close');
//                        noCallback();
//                });
//            }

        </script>

</body>

</html>

        

