</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <link href="UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="stylecss.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div class="uk-container form-container uk-container-small uk-position-center uk-animation-fade">
        <div class="uk-card mod-card uk-position-center uk-card-default ">
            <h3 class="h3-title">JOB ORDER SYSTEM</h3>
            <form class="uk-horizontal login-form">
                <input class="uk-input input" type="text" placeholder="username" required>
                <br>
                <input class="uk-input input" type="password" placeholder="password" required>
                <br>
                <button class="uk-button uk-button-default login-button" type="submit" name="login">LOG IN</button>
            </form>
        </div>
    </div>

    <script src="Jquery/jquery-1.10.2.min.js">
    </script>
    <script src="Jquery/jquery.min.js"></script>
    <script src="UIKIT/js/uikit.js">
    </script>
</body>

</html>