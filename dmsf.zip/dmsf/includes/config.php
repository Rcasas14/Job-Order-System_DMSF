<?php
	require("../includes/db_connection.php");
	include("../includes/functions.php");
?>

<!-- login -->
<?php
	if(isset($_POST['login'])) { 
		login();
	}
?>

<!-- toSearch -->
<?php
	 if(isset($_POST['toSearch'])){
         var_dump($_POST);
     }
?>

<!-- date range -->
<?php
	if(isset($_POST['search'])) {
        date_range();
	}
?>

<!-- approve -->
<?php
	if(isset($_GET['action'])) {
        $id = mysqli_real_escape_string($connection, $_GET['id']);
        $username = mysqli_real_escape_string($connection, $_GET['username']);
		$password = mysqli_real_escape_string($connection, $_GET['password']);
        $action = mysqli_real_escape_string($connection, $_GET['action']);
        if($action == '1'){
            if($user_type=='4'){
                echo "Invalid user!";
            }else{
                echo "Acknowledge!";
            }
        }elseif($action == '2'){
            $query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
            $results = mysqli_query($connection, $query);
            $logged_in_user = mysqli_fetch_assoc($results);
            $reqby = $logged_in_user['init'];
            $user_type = $logged_in_user['user_id'];

            if($user_type=='2'){
                apprvby2($id, $reqby);
                echo "Success!";
            }elseif($user_type=='3'){
                apprvby1($id, $reqby);
                echo "Success!";
            }else{
                echo "Invalid user!";
            }
        }elseif($action == '3'){
            if($user_type=='4'){
                echo "Invalid user!";
            }else{
                echo "Disapprove!";
            }
            
        }
	}
?>
