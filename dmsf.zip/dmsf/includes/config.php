<?php
	require("../includes/db_connection.php");
	include("../includes/functions.php");
?>

<!-- login -->
<?php
	if(isset($_POST['login'])) { 
		login();
	}
?>

<!-- toSearch -->
<?php
	 if(isset($_POST['toSearch'])){
         var_dump($_POST);
     }
?>

<!-- date range -->
<?php
	if(isset($_POST['search'])) {
        date_range();
	}
?>

<!-- approve -->
<?php
	if(isset($_GET['id'])) {
        $id = mysqli_real_escape_string($connection, $_GET['id']);
        $username = mysqli_real_escape_string($connection, $_GET['username']);
		$password = mysqli_real_escape_string($connection, $_GET['password']);
 
        $query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
        $results = mysqli_query($connection, $query);
        $logged_in_user = mysqli_fetch_assoc($results);
        $reqby = $logged_in_user['init'];
        $user_type = $logged_in_user['user_id'];

        if($user_type=='2'){
            apprvby2($id, $reqby);
            $msg = "Success!";
            echo "<script type='text/javascript'>alert('$msg');</script>";
            echo "<script>setTimeout(\"location.href = 'http://localhost/dmsf/users/index.php';\",500);</script>";
            // echo "<script>location.reload();</script>";
        }elseif($user_type=='3'){
            apprvby1($id, $reqby);
            $msg = "Success!";
            echo "<script type='text/javascript'>alert('$msg');</script>";
            echo "<script>setTimeout(\"location.href = 'http://localhost/dmsf/users/index.php';\",500);</script>";
        }else{
            $msg = "Invalid user!";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }
        
	}
?>
