<?php 

    // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    $d = date('F d, Y |', time());
    
    global $logged_in_user;
    global $logged_in_user_type;
    global $logged_in_user_dept;
    global $logged_init;
    global $logged_deptcode;
    
?>

<body onload=display_ct();>

<div class="uk-container-extend">

    <div class="nav-container">
        <a class="user-type">
            <?php echo $logged_in_user_type; ?>
        </a>
        <div>
        <a class="user-type uk-button logout-button" type="button"><?php echo $logged_in_user; ?>
            </a>
        <!-- TEMPORARY -->
        <div uk-dropdown="mode:click" class="div-logout">
            <a href="../includes/logout.php" style="color: #000; text-decoration: none;">Logout</a>
        </div>
        </div>
        <p class="user-type">
            <?php echo $d; ?>
            <span id='ct'></span>
        </p>
        <p class="dept-desc">
            <a href="../users/index.php"><?php echo $logged_in_user_dept; ?></a>
        </p>
    </div>


</div>
</body>
<script type="text/javascript">
            function display_c() {
                var refresh = 1000; // Refresh rate in milli seconds
                mytime = setTimeout('display_ct()', refresh)
            }

        function display_ct() {
            var x = new Date($.now());
            var x1 = x.toLocaleTimeString(); // changing the display to UTC string
            document.getElementById('ct').innerHTML = x1;
            tt = display_c();
        }
    </script>