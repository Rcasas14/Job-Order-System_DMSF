<?php 

    // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    $d = date('F d, Y | h:iA', time());
    
    global $logged_in_user;
    global $logged_in_user_type;
    global $logged_in_user_dept;
    global $logged_init;
    global $logged_deptcode;
    
?>


    <div class="uk-container-extend">

        <div class="nav-container">
            <p class="user-type"><?php echo $logged_in_user_type; ?></p>
            <p class="user-type">
                <!-- TEMPORARY -->
                <a href="../includes/logout.php" style="color: white; text-decoration: none;">
                <?php echo $logged_in_user; ?>
                </a>
            </p>
            <p class="user-type"><?php echo $d; ?></p>
            <p class="dept-desc"><?php echo $logged_in_user_dept; ?></p>
        </div>
        

            </div>
