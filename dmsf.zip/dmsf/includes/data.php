<?php
	require("../includes/db_connection.php");
	include("../includes/functions.php");
    include("../includes/session.php");

    global $logged_deptcode;

	// Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    
    $dt = date("Y-m-d H:i:s", time());

	$username = mysqli_real_escape_string($connection, $_GET['username']);
	$password = mysqli_real_escape_string($connection, $_GET['password']);
	$todept = mysqli_real_escape_string($connection, $_GET['todept']);
	$jotitle = mysqli_real_escape_string($connection, $_GET['jotitle']);
	$jorem = mysqli_real_escape_string($connection, $_GET['jorem']);
    
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
	$results = mysqli_query($connection, $query);
	$logged_in_user = mysqli_fetch_assoc($results);
	$reqby = $logged_in_user['init'];
	$reqdept = $logged_in_user['dept_id'];

	if(!$results) {
        die("Database query failed.");
    }else{
        if($logged_deptcode==$reqdept){
            $query = "INSERT INTO joHeader(jodate, reqdept, todept, jotitle, jorem, reqby) values ('{$dt}', '{$reqdept}', '{$todept}', '{$jotitle}', '{$jorem}', '{$reqby}')";
            $results = mysqli_query($connection, $query);

            if(!$results) {
                die("Database query failed. " . mysqli_error($connection));
            }else{
                $msg = "Success!";
                echo "<script type='text/javascript'>alert('$msg');</script>";
                echo "<script>setTimeout(\"location.href = 'http://localhost/dmsf/users/index.php';\",500);</script>";
            }
            
            
        }elseif(mysqli_num_rows($results) == 0 || mysqli_num_rows($results) > 1){
            $msg = "Invalid user!";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }else{
            $msg = "Invalid user!";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }
	}
?>