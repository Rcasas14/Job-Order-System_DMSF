<?php
	function redirect_to($new_location){
		header("Location: " . $new_location);
		exit;
	}


	function login(){
		global $connection;
		// grab form values

		session_start();

		$username = mysqli_real_escape_string($connection, $_POST['username']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);

		$query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
		$results = mysqli_query($connection, $query);

		$logged_in_user = mysqli_fetch_assoc($results);



		$query_dept = "SELECT * FROM department WHERE dept_id = ". $logged_in_user['dept_id'];
		$result_dept = mysqli_query($connection, $query_dept);
		$user_dept = mysqli_fetch_assoc($result_dept);

		if (mysqli_num_rows($results) == 1) { // user found
            
			// access redirection
			if ($logged_in_user['user_id'] == '1') {
				//redirect to admin's page

				$_SESSION["admin_usertype"] = "Admin";
                $_SESSION["admin_deptname"] = $user_dept['dept_name'];
                $_SESSION["adminname"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/admin/index.php");
			}elseif($logged_in_user['user_id'] == '2'){
				//redirect to depthead's page
                $_SESSION["dhead_usertype"] = "Department Head";
                $_SESSION["dhead_deptname"] = $user_dept['dept_name'];
                $_SESSION["dheadname"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/depthead/index.php");
			}elseif ($logged_in_user['user_id'] == '3'){
				//redirect to unithead's page
                $_SESSION["uhead_usertype"] = "Unit Head";
                $_SESSION["uhead_deptname"] = $user_dept['dept_name'];
                $_SESSION["uhead_username"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/unithead/index.php");
			}elseif($logged_in_user['user_id'] == '4'){
				//redirect to staff's page
                $_SESSION["staff_usertype"] = "Staff";
                $_SESSION["staff_deptname"] = $user_dept['dept_name'];
                $_SESSION["staff_username"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/staff/index.php");
			}else{
				echo "error!";
			}

		}else {
			echo "error haha";
		}
	}


	function request($date){
		global $connection;

		$requested_by = mysqli_real_escape_string($connection, $_GET['name']);
		$dept_name = mysqli_real_escape_string($connection, $_GET['dept']);
		$requested_to = mysqli_real_escape_string($connection, $_POST['requested_to']);
		$jor_title = mysqli_real_escape_string($connection, $_POST['jor_title']);
		$jor_description = mysqli_real_escape_string($connection, $_POST['jor_description']);
        $today = $date;

		$query = "INSERT INTO request_form(requested_by, dept_name, requested_to, jor_title, jor_description, order_date, status) values ('{$requested_by}', '{$dept_name}', '{$requested_to}', '{$jor_title}', '{$jor_description}', '{$today}', 'Pending')";
		$results = mysqli_query($connection, $query);

		 if($results) {
		      echo "nice";
		      redirect_to("../users/unithead/index.php");

    	}else{
      		die("Database query failed. " . mysqli_error($connection));
    	}

	}

    function date_range(){
        global $connection;
        
        $dateFrom = mysqli_real_escape_string($connection, $_POST['date_from']);
        $dateTo = mysqli_real_escape_string($connection, $_POST['date_to']);

        $datefrom=date_create($dateFrom);
		$dateto=date_create($dateTo);

		$date_from = date_format($datefrom,"Y/m/d H:i:s");
		$date_to = date_format($dateto,"Y/m/d H:i:s");

        $query = "SELECT * FROM request_form WHERE order_date BETWEEN '$date_from' and '$date_to'";
        $result = mysqli_query($connection, $query);
        if(!$result) {
          die("Database query failed.");
        }else{
          $rowcount=mysqli_num_rows($result);
        }

        var_dump($date_from);
        var_dump($date_to);
        var_dump($rowcount);
        var_dump($query);

        while($row=mysqli_fetch_assoc($result)){
        	var_dump($row);
        }
        
    }

?>