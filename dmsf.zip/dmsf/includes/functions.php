<?php
    include("../includes/datetime.php");

	function redirect_to($new_location){
		header("Location: " . $new_location);
		exit;
	}


	function login(){
		global $connection;
		// grab form values

		session_start();

		$username = mysqli_real_escape_string($connection, $_POST['username']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);

		$query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
		$results = mysqli_query($connection, $query);

		$logged_in_user = mysqli_fetch_assoc($results);

		$query_dept = "SELECT * FROM department WHERE dept_code = ". $logged_in_user['dept_id'];
		$result_dept = mysqli_query($connection, $query_dept);
		$user_dept = mysqli_fetch_assoc($result_dept);

		if (mysqli_num_rows($results) == 1) { // user found
            
			// access redirection
			if ($logged_in_user['user_id'] == '1') {
				//redirect to admin's page
				$_SESSION["usertype"] = "Admin";
                $_SESSION["deptname"] = $user_dept['dept_name'];
                $_SESSION["fname"] = $logged_in_user['fname'];
                $_SESSION["deptcode"] = $user_dept['dept_code'];
                $_SESSION["init"] = $logged_in_user['init'];
				redirect_to("../users/index.php");
			}elseif($logged_in_user['user_id'] == '2'){
				//redirect to depthead's page
                $_SESSION["usertype"] = "Department Head";
                $_SESSION["deptname"] = $user_dept['dept_name'];
                $_SESSION["fname"] = $logged_in_user['fname'];
                $_SESSION["deptcode"] = $user_dept['dept_code'];
                $_SESSION["init"] = $logged_in_user['init'];
				redirect_to("../users/index.php");
			}elseif ($logged_in_user['user_id'] == '3'){
				//redirect to unithead's page
                $_SESSION["usertype"] = "Unit Head";
                $_SESSION["deptname"] = $user_dept['dept_name'];
                $_SESSION["fname"] = $logged_in_user['fname'];
                $_SESSION["deptcode"] = $user_dept['dept_code'];
                $_SESSION["init"] = $logged_in_user['init'];
				redirect_to("../users/index.php");
			}elseif($logged_in_user['user_id'] == '4'){
				//redirect to staff's page
                $_SESSION["usertype"] = "Staff";
                $_SESSION["deptname"] = $user_dept['dept_name'];
                $_SESSION["fname"] = $logged_in_user['fname'];
                $_SESSION["deptcode"] = $user_dept['dept_code'];
                $_SESSION["init"] = $logged_in_user['init'];
				redirect_to("../users/index.php");
			}else{
				echo "Invalid User";
			}

		}else {
//            echo "User doesn't exist!";
			redirect_to("../public/loginPage.php?error=unknown");
		}
	}


	function request($date){
		global $connection;

		$reqby = mysqli_real_escape_string($connection, $_GET['name']);
		$reqdept = mysqli_real_escape_string($connection, $_GET['dept']);
		$todept = mysqli_real_escape_string($connection, $_POST['todept']);
		$jotitle = mysqli_real_escape_string($connection, $_POST['jor_title']);
		$jorem = mysqli_real_escape_string($connection, $_POST['jor_description']);
        $today = $date;

		$query = "INSERT INTO joHeader(jodate, reqdept, todept, jotitle, jorem, reqby) values ('{$today}', '{$reqdept}', '{$todept}', '{$jotitle}', '{$jorem}', '{$reqby}')";
		$results = mysqli_query($connection, $query);

		 if($results) {
		      echo "nice";
		      redirect_to("../users/unithead/index.php");

    	}else{
      		die("Database query failed. " . mysqli_error($connection));
    	}

	}

    function date_range($dept){
        global $connection;
        
        //grab values
        $dateFrom = mysqli_real_escape_string($connection, $_POST['date_from']);
        $dateTo = mysqli_real_escape_string($connection, $_POST['date_to']);

        //CHANGE FORMAT sa DATE! Savvy?
        //dateFrom
        $datefrom = date_create($dateFrom); 
		$date_from = date_format($datefrom, "Y/m/d H:i:s"); //date_from final_na_hahaha
        
        //dateTo
        $d = date_create($dateTo); 
        //change dateTo format into Y/m/d instead of Y-m-d
        $toDate = date_format($d, "Y/m/d");
        //dateTo final format Y/m/d 23:59:59
        $time = date('G:i:s', mktime(0,0,0)-1);
		$date_to = $toDate ." ". $time; //date_to final_na_hahaha
        
        
        $query = "SELECT * FROM joHeader WHERE jodate BETWEEN '$date_from' and '$date_to' and reqdept = '$dept' ORDER BY jodate DESC";
        $result = mysqli_query($connection, $query);
        if(!$result) {
          die("Database query failed.");
        }else{
            $rowcount=mysqli_num_rows($result);
            
            while($row=mysqli_fetch_assoc($result)){
                $jor_num = $row['jo_num'];
                $requested_by = $row['reqby'];
                $dept_name = $row['reqdept'];
                $requested_to = $row['todept'];
                $jor_title = $row['jotitle'];
                $jor_description = $row['jorem'];
                $order_date = $row['jodate'];
                
                $date = date_create($order_date);
                $fname = get_user($requested_by);
                $dept = get_dept($requested_to);
                
                echo" <tr> 
                    <td>".$jor_num."</td>
                    <td>".date_format($date, "F d, Y / g:ia")."</td>
                    <td>".$dept."</td>
                    <td class=\"uk-text-truncate\">".$jor_title."</td>
                    <td>".$fname."</td>
                    <td><a href=\"view-details.php?id=$jor_num\"><button type=\"button\" class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                    </tr>";
            }
        }
                         
    }

    function apprvby1($id, $init){
        global $connection;
        global $date;
        
		$query = "UPDATE joHeader SET apprby1 = '$init', apprv1_date = '$date' WHERE jo_num = '$id'";   
        $result = mysqli_query($connection, $query);
        
        if(!$result) {
          die("Database query failed.");
            
        } 
    }

    function apprvby2($id, $init){
        global $connection;
        global $date;
        
		$query = "UPDATE joHeader SET apprby2 = '$init', apprv2_date = '$date' WHERE jo_num = '$id'";   
        $result = mysqli_query($connection, $query);
        
        var_dump($query);
        if(!$result) {
          die("Database query failed.");
            
        } 
    }

    function get_user($init){
        global $connection;
        
        $query = "SELECT * FROM users WHERE init='$init' LIMIT 1";
		$results = mysqli_query($connection, $query);
        $logged_init_user = mysqli_fetch_assoc($results);
        $initials = $logged_init_user['fname'];
        
        return $initials;
    }

    function get_dept($todept){
        global $connection;
        
        $query = "SELECT * FROM department WHERE dept_code='$todept' LIMIT 1";
		$result = mysqli_query($connection, $query);
        $logged_init_dept = mysqli_fetch_assoc($result);
        $dept = $logged_init_dept['dept_name'];
        
        return $dept;
    }

    function get_data(){
        global $connection;
        $jor_num = mysqli_real_escape_string($connection, $_GET['id']);
        $query = "SELECT * FROM joHeader WHERE jo_num = '$jor_num' LIMIT 1";
        $results = mysqli_query($connection, $query);
        $data = mysqli_fetch_assoc($results);
    }

    function staff_pending(){
        global $connection;
        $logged_deptcode = $_SESSION["deptcode"];
        $query = "SELECT * FROM `joheader` WHERE reqdept='$logged_deptcode' and apprby1 is null or apprby2 is null order by jodate desc";
        $result = mysqli_query($connection, $query);
        if(!$result) {
            die("Database query failed.");
        }
          
        while($row=mysqli_fetch_assoc($result)){
            $jor_num = $row['jo_num'];
            $requested_by = $row['reqby'];
            $dept_name = $row['reqdept'];
            $requested_to = $row['todept'];
            $jor_title = $row['jotitle'];
            $jor_description = $row['jorem'];
            $order_date = $row['jodate'];
            
            $date = date_create($order_date);
            $fname = get_user($requested_by);
            $dept = get_dept($requested_to);
            
            echo"<tr>
                <td>".$jor_num."</td>
                <td>".date_format($date, "F d, Y / g:ia")."</td>
                <td>".$dept."</td>
                <td class=\"uk-text-truncate\">".$jor_title."</td>
                <td>".$fname."</td>
                <td><a href=\"view-details.php?id=$jor_num\"><button class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                </tr>";
        }
    }
    
    function unithead_pending(){
        global $connection;
        $logged_deptcode = $_SESSION["deptcode"];
        $query = "SELECT * FROM `joheader` WHERE reqdept='$logged_deptcode' and apprby1 is null and apprby2 is null order by jodate desc";
        
        $result = mysqli_query($connection, $query);
        if(!$result) {
            die("Database query failed.". mysqli_error($connection));
        }
          
        while($row=mysqli_fetch_assoc($result)){
            $jor_num = $row['jo_num'];
            $requested_by = $row['reqby'];
            $dept_name = $row['reqdept'];
            $requested_to = $row['todept'];
            $jor_title = $row['jotitle'];
            $jor_description = $row['jorem'];
            $order_date = $row['jodate'];
            
            $date = date_create($order_date);
            $fname = get_user($requested_by);
            $dept = get_dept($requested_to);
            
            echo"<tr>
                <td>".$jor_num."</td>
                <td>".date_format($date, "F d, Y / g:ia")."</td>
                <td>".$dept."</td>
                <td class=\"uk-text-truncate\">".$jor_title."</td>
                <td>".$fname."</td>
                <td><a href=\"view-details.php?id=$jor_num\"><button class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                </tr>";
        }
    }


    function depthead_pending(){
        global $connection;
        $logged_deptcode = $_SESSION["deptcode"];
        $query = "SELECT * FROM `joheader` WHERE reqdept='$logged_deptcode' and apprby1 is not null and apprby2 is null order by apprv1_date desc";
        $result = mysqli_query($connection, $query);
        if(!$result) {
            die("Database query failed.");
        }
          
        while($row=mysqli_fetch_assoc($result)){
            $jor_num = $row['jo_num'];
            $requested_by = $row['reqby'];
            $dept_name = $row['reqdept'];
            $requested_to = $row['todept'];
            $jor_title = $row['jotitle'];
            $jor_description = $row['jorem'];
            $order_date = $row['jodate'];
            
            $date = date_create($order_date);
            $fname = get_user($requested_by);
            $dept = get_dept($requested_to);
            
            echo"<tr>
                <td>".$jor_num."</td>
                <td>".date_format($date, "F d, Y / g:ia")."</td>
                <td>".$dept."</td>
                <td class=\"uk-text-truncate\">".$jor_title."</td>
                <td>".$fname."</td>
                <td><button class=\"td-view-button\" name=\"action-view\"><a href=\"view-details?id=$jor_num\">View</a></button></td>
                </tr>";
        }
    }

    function staff_approved(){
        global $connection;
        $logged_deptcode = $_SESSION["deptcode"];
        $query = "SELECT * FROM `joheader` WHERE reqdept='$logged_deptcode' and apprby1 is not null and apprby2 is not null order by apprv2_date desc";
        $result = mysqli_query($connection, $query);
        if(!$result) {
            die("Database query failed.");
        }
          
        while($row=mysqli_fetch_assoc($result)){
            $jor_num = $row['jo_num'];
            $requested_by = $row['reqby'];
            $dept_name = $row['reqdept'];
            $requested_to = $row['todept'];
            $jor_title = $row['jotitle'];
            $jor_description = $row['jorem'];
            $order_date = $row['jodate'];
            $apprvdate = $row['apprv2_date'];
            
            $date = date_create($order_date);
            $appdate = date_create($apprvdate);
            $fname = get_user($requested_by);
            $dept = get_dept($requested_to);
            
            echo"<tr>
                <td>".$jor_num."</td>
                <td>".date_format($date, "F d, Y / g:ia")."</td>
                <td>".$dept."</td>
                <td class=\"uk-text-truncate\">".$jor_title."</td>
                <td>".$fname."</td>
                <td>".date_format($appdate, "F d, Y / g:ia")."</td>
                <td><a href=\"view-details.php?id=$jor_num\"><button class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                </tr>";
        }
    }
    
    function unithead_approved(){
        global $connection;
        $logged_deptcode = $_SESSION["deptcode"];
        $query = "SELECT * FROM `joheader` WHERE reqdept='$logged_deptcode' and apprby1 is not null and apprby2 is null order by apprv1_date desc";
        
        $result = mysqli_query($connection, $query);
        if(!$result) {
            die("Database query failed.". mysqli_error($connection));
        }
          
        while($row=mysqli_fetch_assoc($result)){
            $jor_num = $row['jo_num'];
            $requested_by = $row['reqby'];
            $dept_name = $row['reqdept'];
            $requested_to = $row['todept'];
            $jor_title = $row['jotitle'];
            $jor_description = $row['jorem'];
            $order_date = $row['jodate'];
            $appr_date = $row['apprv1_date'];
            
            $date = date_create($order_date);
            $apprvdate = date_create($appr_date);
            $fname = get_user($requested_by);
            $dept = get_dept($requested_to);
            
            echo"<tr>
                <td>".$jor_num."</td>
                <td>".date_format($date, "F d, Y / g:ia")."</td>
                <td>".$dept."</td>
                <td class=\"uk-text-truncate\">".$jor_title."</td>
                <td>".$fname."</td>
                <td>".date_format($apprvdate, "F d, Y / g:ia")."</td>
                <td><a href=\"view-details.php?id=$jor_num\"><button class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                </tr>";
        }
    }
        
    function depthead_approved(){
        global $connection;
        $logged_deptcode = $_SESSION["deptcode"];
        $query = "SELECT * FROM `joheader` WHERE reqdept='$logged_deptcode' and apprby1 is not null and apprby2 is not null order by apprv2_date desc";
        $result = mysqli_query($connection, $query);
        if(!$result) {
            die("Database query failed.");
        }
          
        while($row=mysqli_fetch_assoc($result)){
            $jor_num = $row['jo_num'];
            $requested_by = $row['reqby'];
            $dept_name = $row['reqdept'];
            $requested_to = $row['todept'];
            $jor_title = $row['jotitle'];
            $jor_description = $row['jorem'];
            $order_date = $row['jodate'];
            $appr_date = $row['apprv2_date'];
            
            $date = date_create($order_date);
            $apprvdate = date_create($appr_date);
            $fname = get_user($requested_by);
            $dept = get_dept($requested_to);
            
            echo"<tr>
                <td>".$jor_num."</td>
                <td>".date_format($date, "F d, Y / g:ia")."</td>
                <td>".$dept."</td>
                <td class=\"uk-text-truncate\">".$jor_title."</td>
                <td>".$fname."</td>
                <td>".date_format($apprvdate, "F d, Y / g:ia")."</td>
                <td><a href=\"view-details.php?id=$jor_num\"><button class=\"td-view-button\" name=\"action-view\">View</button></a></td>
                </tr>";
        }
    }

    function get_app1($id){
        global $connection;
        
        $query = "SELECT * FROM joHeader WHERE jo_num =$id";
        $result = mysqli_query($connection, $query);
        $fetch = mysqli_fetch_assoc($result);
        $app = $fetch['apprby1'];
        $app2 = $fetch['apprv1_date'];
        if(!$result) {
            die("Database query failed." . mysqli_error($connection));
        }else{
            return array($app, $app2);
        }
        
    }

    function get_app2($id){
        global $connection;
        
        $query = "SELECT * FROM joHeader WHERE jo_num =$id";
        $result = mysqli_query($connection, $query);
        $fetch = mysqli_fetch_assoc($result);
        $app = $fetch['apprby2'];
        $app2 = $fetch['apprv2_date'];
        if(!$result) {
            die("Database query failed." . mysqli_error($connection));
        }else{
            return array($app, $app2);
        }
        
    }
    
?>
