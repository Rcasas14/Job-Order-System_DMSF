<?php 
    session_start();
    
    $logged_in_user = $_SESSION["fname"];
    $logged_in_user_type = $_SESSION["usertype"];
    $logged_in_user_dept = $_SESSION["deptname"];
    $logged_init = $_SESSION["init"];
    $logged_deptcode = $_SESSION["deptcode"];

?>