<?php
    session_start();
    include("../includes/functions.php");
?>

<?php  
	session_destroy();
	$_SESSION["usertype"] = null;
    $_SESSION["deptname"] = null;
    $_SESSION["fname"] = null;
    $_SESSION["init"] = null;
    $_SESSION["deptcode"] = null;

    redirect_to("../public/loginPage.php");
?>
