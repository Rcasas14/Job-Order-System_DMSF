<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<pre>
	<?php 
		print_r($_POST);
	?>
</pre>

<pre>
	<?php 
		if(isset($_POST["login"])){
			echo "Successful!";

			if (isset($_POST["username"])) {
				$username = $_POST["username"];
			}else{
				$username = "";
			}

			if (isset($_POST["password"])) {
				$password = $_POST["password"];
			}else{
				$password = "";
			}

			$username = isset($_POST["username"]) ? $_POST["username"] : "";
			$password = isset($_POST["password"]) ? $_POST["password"] : "";

		}else{
			$username = "";
			$password = "";
			echo "Failed";
			
		}
	?>
</pre>
</body>
</html>