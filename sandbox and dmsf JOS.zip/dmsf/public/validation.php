<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php  
		$value="x";
		if(!isset($value) || empty($value)){
			echo "validation failed";
		}
	?>
</body>
</html>