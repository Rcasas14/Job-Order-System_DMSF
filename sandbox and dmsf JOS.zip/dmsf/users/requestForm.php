<?php
session_start();
        // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:i:s", time());
    $today = date_create($det);
    
    $logged_in_user = $_SESSION["uhead_username"];
    $logged_in_user_type = $_SESSION["uhead_usertype"];
    $logged_in_user_dept = $_SESSION["uhead_deptname"];
?>
    </!DOCTYPE html>
    <html>

    <head>
        <title>Job Order System
        </title>
        <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
        <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
        <link href="../css/stylecss.css" rel="stylesheet" type="text/css">
    </head>

    <body class="ind-body">
        <div class="uk-container uk-animation-fade">
            <div class="request-form uk-card uk-card-default uk-position-center">
                <div class=" req-modal uk-margin uk-form-width-large">
                    <form class="uk-form form-style" action="../../includes/config.php?date=<?php echo $det; ?>&&name=<?php echo $logged_in_user; ?>&&dept=<?php echo $logged_in_user_dept; ?>" method="POST">

                        <div class="form-title">
                            <h2 class="uk-modal-title">REQUEST FORM</h2>
                            <p>
                                <span class="date">Date: </span>
                                <b><?php echo date_format($today, "F d, Y | g:ia"); ?></b>
                            </p>
                        </div><br>
                        <p>
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="name">Name: </span>
                                <b><?php echo $logged_in_user; ?></b>
                                <!-- <input class="uk-input modal-input " type="text" name="requested_by" value="<?php echo $logged_in_user; ?>" readonly> -->
                            </div>
                        </p>
                        <p>
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="depart">Department: </span>
                                <b><?php echo $logged_in_user_dept; ?></b>
                                <!-- <input class="uk-input modal-input" type="text" name="dept_name" value="<?php echo $logged_in_user_dept; ?>" readonly> -->
                            </div>
                        </p>
                        <p>
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="to-req">Request To:</span>
                                <select name="requested_to" class="uk-form-control">
                                        <option value selected ></option>
                                        <option value="Engineering">Engineering</option>
                                        <option value="ISDU">ISDU</option>
                                    </select>
                            </div>
                        </p>
                        <p class="job-order-title">
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="job-title">JOB ORDER TITLE: </span>
                                <input class="uk-input modal-input" type="text" name="jor_title" required>
                            </div>
                        </p>
                        <span>Description Of The Problem:</span>
                        <textarea class="uk-textarea" rows="6" name="jor_description" required></textarea>
                        <p class="uk-text-right">
                            <a class="uk-button uk-button-default" href="unithead/index.php">Back</a>
                            <!--Dapat nasa gawas ang index.php para re direct sa back-->
                            <button class="uk-button uk-button-primary" type="submit" name="submit" value="submit">Submit</button>
                        </p>
                    </form>


                </div>
            </div>
        </div>

        <script src="../css/Jquery/Jquery/jquery-1.10.2.min.js"></script>
        <script src="../css/Jquery/jquery.min.js"></script>
        <script src="../css/UIKIT/js/uikit.js"></script>
    </body>

    </html>