</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <link href="../UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="../UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="../stylecss.css" rel="stylesheet" type="text/css">
</head>

<body class="ind-body">
    <div class="uk-container uk-animation-fade">
        <div class="uk-card request-table-card uk-position-center uk-card-default">
            <div class="top-section">
                <p class="dept-name">OPERATING ROOM</p>
                <div class="uk-inline float">
                    <a class="user-details" href="#">Diane, UnitHead</a>
                    <div uk-drop="mode: click">
                        <a class="logout">Logout</a>
                    </div>
                </div>
            </div>
            <div class="request-list">
                <input class="uk-input uk-form-small date-sort" type="date" name="from-date-sort">
                <input class="uk-input uk-form-small date-sort" type="date" name="to-date-sort">
                <button class="uk-button search-button uk-button-default " type="button">SEARCH</button>
                <div class="uk-card uk-card-default">
                    <button class="uk-button uk-button-default request-button" type="button" name="new-request" uk-icon="plus" uk-toggle="target: #request-form">NEW REQUEST</button>
                </div>
                <div class=" table-container uk-margin">
                    <br>
                    <ul class="uk-subnav uk-subnav-pill" uk-switcher="animation: uk-animation-fade">
                        <li><a href="#">All List</a></li>
                        <li><a href="#">Pending List</a></li>
                        <li><a href="#">Approved List</a></li>
                    </ul>
                    <ul class="uk-switcher uk-margin">
                        <li>
                            <div class="uk-table tableMargin">
                                <table class="uk-table request-table uk-table-responsive uk-table-divider">
                                    <thead class="req-thead">
                                        <tr>
                                            <th>JOB ORDER #</th>
                                            <th>REQUEST BY:</th>
                                            <th>REQUEST TO:</th>
                                            <th>JOB ORDER TITLE</th>
                                            <th>JO DATE</th>
                                            <th>STATUS</th>
                                        </tr>
                                    </thead>
                                    <tbody class="req-td">
                                        <tr uk-toggle="target: #request-details">
                                            <td>01</td>
                                            <td>Diane Cervantes</td>
                                            <td>ISDU</td>
                                            <td>PRINTER DEFECTIVE</td>
                                            <td>7|09|2018</td>
                                            <td>PENDING</td>
                                        </tr>
                                        <tr uk-toggle="target: #request-details" >
                                            <td>01</td>
                                            <td>Diane Cervantes</td>
                                            <td>ISDU</td>
                                            <td>PRINTER DEFECTIVE</td>
                                            <td>7|09|2018</td>
                                            <td>PENDING</td>
                                        </tr>
                                        <tr>
                                            <td>01</td>
                                            <td>Diane Cervantes</td>
                                            <td>ISDU</td>
                                            <td>PRINTER DEFECTIVE</td>
                                            <td>7|09|2018</td>
                                            <td>PENDING</td>
                                        </tr>
                                        <tr>
                                            <td>01</td>
                                            <td>Diane Cervantes</td>
                                            <td>ISDU</td>
                                            <td>PRINTER DEFECTIVE</td>
                                            <td>7|09|2018</td>
                                            <td>PENDING</td>
                                        </tr>
                                        <tr>
                                            <td>01</td>
                                            <td>Diane Cervantes</td>
                                            <td>ISDU</td>
                                            <td>PRINTER DEFECTIVE</td>
                                            <td>7|09|2018</td>
                                            <td>PENDING</td>
                                        </tr>

                                    </tbody>
                                </table>
                        </li>
                    </ul>
                    </div>
                    <div id="request-details" uk-modal>
                        <div class="uk-modal-dialog req-modal uk-modal-body uk-margin" uk-overflow-auto>
                            <form class="uk-form form-style">

                                <div class="form-title">
                                    <h2 class="uk-modal-title">JOB ORDER TITLE HERE</h2>
                                </div>
                                <div class="date">
                                    <span>
                                Job order date: (readonly)
                                <b>
                                    
                                </b>
                            </span>
                                </div>
                                <p>
                                    <div class="uk-form-select" data-uk-form-select>
                                        <span class="name">Requested By: (readonly)</span>

                                    </div>
                                </p>
                                <p>
                                    <div class="uk-form-select" data-uk-form-select>
                                    </div>
                                </p>
                                <p>
                                    <div class="uk-form-select" data-uk-form-select>
                                        <span class="to-req">Request To:ISDU (readonly)</span>
                                    </div>
                                </p>
                                <span>Description Of The Problem:</span>
                                <p>Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom Lurem ipsom </p>

                                <p>
                                    <div class="uk-form-select" data-uk-form-select>
                                        <span class="name">Status: Approved/Pending</span>
                                    </div>
                <button class="uk-button uk-button-default uk-modal-close">Close</button>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
                <script src="../table.js"></script>
                <script src="../Jquery/jquery-1.10.2.min.js"></script>
                <script src="../Jquery/jquery.min.js"></script>
                <script src="../UIKIT/js/uikit.js"></script>
</body>

</html>