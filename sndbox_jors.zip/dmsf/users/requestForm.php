<?php
    session_start();
     // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    
    $dt = date("Y-m-d H:i:s", time());
    
    $logged_in_user = $_SESSION["uhead_username"];
    $logged_in_user_type = $_SESSION["uhead_usertype"];
    $logged_in_user_dept = $_SESSION["uhead_deptname"];
?>
    </!DOCTYPE html>
    <html>

    <head>
        <title>Job Order System
        </title>
        <link href="../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
        <link href="../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
        <link href="../css/stylecss.css" rel="stylesheet" type="text/css">
    </head>

    <body class="ind-body">
        <div class="uk-container uk-animation-fade">
            <div class="request-form uk-card uk-card-default uk-position-center">
                <div class=" req-modal uk-margin uk-form-width-large">
                    <form name="request_form" class="uk-form form-style" action="../includes/config.php?date=<?php echo $dt; ?>&&name=<?php echo $logged_in_user; ?>&&dept=<?php echo $logged_in_user_dept; ?>" method="POST">

                        <div class="form-title">
                            <h2 class="uk-modal-title">REQUEST FORM</h2>
                        </div>
                        <div class="date">
                            <span>
                                Date: 
                                <b>
                                    <?php echo date_format($today, "F d, Y | h:ia");?>
                                </b>
                            </span>
                        </div>
                        <p>
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="name">Name: </span>
                                <b><?php echo $logged_in_user; ?></b>
                                <!-- <input class="uk-input modal-input " type="text" name="requested_by" value="<?php echo $logged_in_user; ?>" readonly> -->
                            </div>
                        </p>
                        <p>
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="depart">Department: </span>
                                <b><?php echo $logged_in_user_dept; ?></b>
                                <!-- <input class="uk-input modal-input" type="text" name="dept_name" value="<?php echo $logged_in_user_dept; ?>" readonly> -->
                            </div>
                        </p>
                        <p>
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="to-req">Request To:</span>
                                <select id="requested_to" name="requested_to" class="uk-form-control">
                                        <option value selected></option>
                                        <option value="Engineering">Engineering</option>
                                        <option value="ISDU">ISDU</option>
                                    </select>
                            </div>
                        </p>
                        <p class="job-order-title">
                            <div class="uk-form-select" data-uk-form-select>
                                <span class="job-title">JOB ORDER TITLE: </span>
                                <input class="uk-input modal-input" type="text" id="jor_title" name="jor_title" required>
                            </div>
                        </p>
                        <span>Description Of The Problem:</span>
                        <textarea class="uk-textarea" rows="6" id="jor_description" name="jor_description" required></textarea>
                        <p class="uk-text-right">
                            <button class="uk-button submit-login uk-button-default uk-margin-small-right"  name="submit" value="Submit" type="submit">Submit                             </button> <!--uk-toggle="target: #modal-example"-->

                            <a class="uk-button submit-login uk-button-default" href="unithead/index.php">Back</a>

                        </p>
                    </form>
                    <form name="request_form" class="uk-form form-style" action="../includes/config.php?date=<?php echo $det; ?>&&name=<?php echo $logged_in_user; ?>&&dept=<?php echo $logged_in_user_dept; ?>" method="POST">
                        <div id="modal-example" uk-modal>
                            <div class="uk-modal-dialog uk-modal-body form-container input-paging">
                                <p>
                                    <h3 class="h3-title">
                                        LOGIN FORM
                                    </h3>
                                    <p>Please Login To Continue</p>

                                    <input class="uk-input input input_bla" type="username" name="username" placeholder="username" required>
                                    <br>
                                    <input class="uk-input input input_bla" type="password" name="password" placeholder="password" required>

                                    <br><br>
                                    <a href="../includes/config.php?val=">
                                        <input id="div-to-write-to" class="uk-button submit-login" name="enter" value="Login" type="submit">
                                    </a>

                                    <button class="uk-button submit-login uk-modal-close">Cancel</button>
                                    <br>
                                </p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script src="../css/Jquery/Jquery/jquery-1.10.2.min.js"></script>
        <script src="../css/Jquery/jquery.min.js"></script>
        <script src="../css/UIKIT/js/uikit.js"></script>

        <script>
            var content = $('#requested_to').val() + '<br>' + $('#jor_title').val() + '<br>' + $('#jor_description').val();
            $('#div-to-write-to').html(content);
        </script>
    </body>

    </html>