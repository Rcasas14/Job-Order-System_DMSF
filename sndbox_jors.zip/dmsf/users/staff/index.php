<?php 
    session_start();
    require("../../includes/db_connection.php");
    include("../../includes/functions.php");

    // Set your timezone!!
    date_default_timezone_set('Asia/Manila');
    $det = date("Y-m-d h:iA", time());
    $today = date_create($det);
    $d = date('F d, Y | h:iA', time());
    
    $logged_in_user = $_SESSION["uhead_username"];
    $logged_in_user_type = $_SESSION["uhead_usertype"];
    $logged_in_user_dept = $_SESSION["uhead_deptname"];

    $dt = date("Y-m-d H:i:s", time());
    
?>



</!DOCTYPE html>
<html>

<head>
    <title>Job Order System
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../css/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../../css/UIKIT/css/uikit.css" rel="stylesheet" type="text/css">
    <link href="../../css/UIKIT/js/uikit.js" rel="stylesheet" type="text/css">
    <link href="../../css/stylecss.css" rel="stylesheet" type="text/css">
    </hhad A <body class="ind-body">


    <div class="uk-container uk-animation-fade">
        <div class="request-list uk-card uk-card-default ">
            
            <!--Navigation Bar-->
            <nav class="uk-navbar-container top-section uk-navbar">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav">
                        <li class="uk-active">
                            <a href="#">
                                <?php echo $logged_in_user_dept; ?>
                            </a>
                        </li>

                    </ul>
                    <div class="uk-navbar-right">
                        <ul class="uk-navbar-nav">
                            <li class="uk-active">
                                <a href="#">
										<b><?php echo $d; ?></b>
									</a>
                            </li>
                            <li class="uk-active">
                                <a href="../../includes/logout.php">
                                    <?php echo $logged_in_user; ?>
                                </a>
                            </li>
                            <li class="uk-active">
                                <a href="#">
                                    <?php echo $logged_in_user_type; ?>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            
            <!--New Request-->
            <div class="uk-margin below-top-section">
                <form class="uk-form" action="#" method="POST">
                    <input class="uk-button search-button uk-button-default" value="Search" name="search" type="submit">
                    <input class="uk-input uk-form-small date-sort" type="date" name="date_to">
                    <input class="uk-input uk-form-small date-sort" type="date" name="date_from">
                </form>
                <a class="uk-button uk-button-default uk-default request-button" href="../requestForm.php">NEW REQUEST</a>
                <br>
            </div>
            
            <div class="uk-margin table-container">
                <ul class="uk-tab uk-tab-flip" data-uk-tab="{connect:'#my-id'}">
                    <li><a href="#">All List</a></li>
                    <li><a href="#">Pending List</a></li>
                    <li><a href="#">Approved List</a></li>
                </ul>
                <ul class="uk-switcher uk-margin">
                    <li>
                        <table class="uk-table request-table">
                            <div class="tt">
                                <thead class="req-thead">
                                    <tr>
                                        <tr>
                                            <th>JOB ORDER #</th>
                                            <th>REQUESTED BY:</th>
                                            <th>REQUESTED TO:</th>
                                            <th>JOB ORDER TITLE</th>
                                            <th>JOB ORDER DATE</th>
                                            <th>STATUS</th>
                                        </tr>
                            </div>
                            </thead>

                            <tbody class="req-td">
                                <?php
                                    if(isset($_POST['search'])) {
                                        date_range($logged_in_user_dept);
                                    }else{
                                        //display table data
                                        $query = "select * from request_form WHERE dept_name = '$logged_in_user_dept' ORDER BY order_date DESC";
                                        $result = mysqli_query($connection, $query);
                                        if(!$result) {
                                            die("Database query failed.");
                                        }
                                        
                                        while($row=mysqli_fetch_assoc($result)){
                                            
                                            $jor_num = $row['jor_num'];
                                            $requested_by = $row['requested_by'];
                                            $dept_name = $row['dept_name'];
                                            $requested_to = $row['requested_to'];
                                            $jor_title = $row['jor_title'];
                                            $jor_description = $row['jor_description'];
                                            $order_date = $row['order_date'];
                                            $status = $row['status'];
                                                  
                                            $date = date_create($order_date);

                                            echo"<tr>
                                                <td>".$jor_num."</td>
                                                <td>".$requested_by."</td>
                                                <td>".$requested_to."</td>
                                                <td>".$jor_title."</td>
                                                <td>".date_format($date, "F d, Y / g:ia")."</td>
                                                <td>".$status."</td>
                                                
                                                </tr>";
                                        }
                                     }
                                ?>
                            </tbody>
                        </table>
                    </li>
                    <li>
                        <table class="uk-table request-table">
                            <div class="tt">
                                <thead class="req-thead">
                                    <tr>
                                        <tr>
                                            <th>JOB ORDER #</th>
                                            <th>REQUESTED BY:</th>
                                            <th>REQUESTED TO:</th>
                                            <th>JOB ORDER TITLE</th>
                                            <th>JOB ORDER DATE</th>
                                            <th>ACTION</th>
                                        </tr>
                            </div>
                            </thead>

                            <tbody class="req-td">
                                <?php
                                    if(isset($_POST['search'])) {
                                        date_range($logged_in_user_dept);
                                    }else{
                                        //display table data
                                        $query_pending = "select * from request_form where status = 'pending' and dept_name = '$logged_in_user_dept' ORDER BY order_date DESC";
                                        
                                        $pending = mysqli_query($connection, $query_pending);
                                        if(!$pending) {
                                            die("Database query failed.");
                                        }
                                        
                                        while($rows=mysqli_fetch_assoc($pending)){
                                            $jor_num = $rows['jor_num'];
                                            $requested_by = $rows['requested_by'];
                                            $dept_name = $rows['dept_name'];
                                            $requested_to = $rows['requested_to'];
                                            $jor_title = $rows['jor_title'];
                                            $jor_description = $rows['jor_description'];
                                            $order_date = $rows['order_date'];
                                                  
                                            $date = date_create($order_date);

                                            echo"<tr>
                                                <td>".$jor_num."</td>
                                                <td>".$requested_by."</td>
                                                <td>".$requested_to."</td>
                                                <td>".$jor_title."</td>
                                                <td>".date_format($date, "F d, Y / g:ia")."</td>
                                                <td><a>View Details</a></td>
                                                
                                                </tr>";
                                        }
                                     }
                                ?>
                            </tbody>
                        </table>
                    </li>
                    <li>
                        <table class="uk-table request-table">
                            <div class="tt">
                                <thead class="req-thead">
                                    <tr>
                                        <tr>
                                            <th>JOB ORDER #</th>
                                            <th>REQUESTED BY:</th>
                                            <th>APPROVED BY:</th>
                                            <th>JOB ORDER TITLE</th>
                                            <th>APPROVED DATE</th>
                                            <th>ACTION</th>
                                        </tr>
                            </div>
                            </thead>

                            <tbody class="req-td">
                                <?php
                                    if(isset($_POST['search'])) {
                                        date_range($logged_in_user_dept);
                                    }else{
                                        //display table data
                                        $query_apprv = "select * from request_form LEFT JOIN approved_tbl ON (request_form.jor_num = approved_tbl.jor_num) WHERE request_form.status = 'approved' and request_form.dept_name = '$logged_in_user_dept' ORDER BY order_date DESC";
                                            
                                            //"select * from request_form where status = 'approved' ORDER BY order_date DESC";
                                        
                                        
                                        $apprv = mysqli_query($connection, $query_apprv);
                                        if(!$apprv) {
                                            die("Database query failed.");
                                        }else{
                                            while($rows=mysqli_fetch_assoc($apprv)){
                                                
                                                
                                            $jor_num = $rows['jor_num'];
                                            $requested_by = $rows['requested_by'];
                                            $jor_title = $rows['jor_title'];
                                            $apprv_date = $rows['apprv_date'];
                                            $apprv_by = $rows['apprv_by'];
                                                  
                                            $date = date_create($apprv_date);

                                            echo"<tr>
                                                <td>".$jor_num."</td>
                                                <td>".$requested_by."</td>
                                                <td>".$apprv_by."</td>
                                                <td>".$jor_title."</td>
                                                <td>".date_format($date, "F d, Y / g:ia")."</td>
                                                <td><a>View Details</a></td>
                                                
                                                </tr>";
                                            }
                                        }
                                     }
                                ?>
                            </tbody>
                        </table>
                    </li>
                </ul>
            </div>
        </div>
    </div>


    </div>

    <script src="../../css/Jquery/jquery-1.10.2.min.js"></script>
    <script src="../../css/Jquery/jquery.min.js"></script>
    <script src="../../css/UIKIT/js/uikit.js"></script>
    <script src="../../css/vendor/jquery/jquery.min.js"></script>
    <script src="../../css/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    </body>

</html>

<!--
    select * from request_form LEFT JOIN approved_tbl ON request_form.jor_num = approved_tbl.jor_num) WHERE request_form.status = 'approved';
-->
