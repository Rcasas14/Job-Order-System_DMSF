<?php
	function redirect_to($new_location){
		header("Location: " . $new_location);
		exit;
	}


	function login(){
		global $connection;
		// grab form values

		session_start();

		$username = mysqli_real_escape_string($connection, $_POST['username']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);

		$query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
		$results = mysqli_query($connection, $query);

		$logged_in_user = mysqli_fetch_assoc($results);



		$query_dept = "SELECT * FROM department WHERE dept_id = ". $logged_in_user['dept_id'];
		$result_dept = mysqli_query($connection, $query_dept);
		$user_dept = mysqli_fetch_assoc($result_dept);

		if (mysqli_num_rows($results) == 1) { // user found
            
			// access redirection
			if ($logged_in_user['user_id'] == '1') {
				//redirect to admin's page

				$_SESSION["uhead_usertype"] = "Admin";
                $_SESSION["uhead_deptname"] = $user_dept['dept_name'];
                $_SESSION["uhead_username"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/admin/index.php");
			}elseif($logged_in_user['user_id'] == '2'){
				//redirect to depthead's page
                $_SESSION["uhead_usertype"] = "Department Head";
                $_SESSION["uhead_deptname"] = $user_dept['dept_name'];
                $_SESSION["uhead_username"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/depthead/index.php");
			}elseif ($logged_in_user['user_id'] == '3'){
				//redirect to unithead's page
                $_SESSION["uhead_usertype"] = "Unit Head";
                $_SESSION["uhead_deptname"] = $user_dept['dept_name'];
                $_SESSION["uhead_username"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/unithead/index.php");
			}elseif($logged_in_user['user_id'] == '4'){
				//redirect to staff's page
                $_SESSION["uhead_usertype"] = "Staff";
                $_SESSION["uhead_deptname"] = $user_dept['dept_name'];
                $_SESSION["uhead_username"] = $logged_in_user['fname'] . " " . $logged_in_user['lname'];
				redirect_to("../users/staff/index.php");
			}else{
				echo "error!";
			}

		}else {
			echo "error haha";
		}
	}


	function request($date){
		global $connection;

		$requested_by = mysqli_real_escape_string($connection, $_GET['name']);
		$dept_name = mysqli_real_escape_string($connection, $_GET['dept']);
		$requested_to = mysqli_real_escape_string($connection, $_POST['requested_to']);
		$jor_title = mysqli_real_escape_string($connection, $_POST['jor_title']);
		$jor_description = mysqli_real_escape_string($connection, $_POST['jor_description']);
        $today = $date;

		$query = "INSERT INTO request_form(requested_by, dept_name, requested_to, jor_title, jor_description, order_date, status) values ('{$requested_by}', '{$dept_name}', '{$requested_to}', '{$jor_title}', '{$jor_description}', '{$today}', 'Pending')";
		$results = mysqli_query($connection, $query);

		 if($results) {
		      echo "nice";
		      redirect_to("../users/unithead/index.php");

    	}else{
      		die("Database query failed. " . mysqli_error($connection));
    	}

	}

    function date_range($dept){
        global $connection;
        
        //grab values
        $dateFrom = mysqli_real_escape_string($connection, $_POST['date_from']);
        $dateTo = mysqli_real_escape_string($connection, $_POST['date_to']);

        //change format
        $datefrom = date_create($dateFrom); //dateFrom
		$date_from = date_format($datefrom, "Y/m/d H:i:s");
        
        $d = date_create($dateTo); //dateTo
        //change dateTo format into Y/m/d instead of Y-m-d
        $toDate = date_format($d, "Y/m/d");
        
        //dateTo final format Y/m/d 23:59:59
        $time = date('G:i:s', mktime(0,0,0)-1);
		$date_to = $toDate ." ". $time;
        
        
        $query = "SELECT * FROM request_form WHERE order_date BETWEEN '$date_from' and '$date_to' and dept_name = '$dept'";
        $result = mysqli_query($connection, $query);
        if(!$result) {
          die("Database query failed.");
        }else{
          $rowcount=mysqli_num_rows($result);
        }

        while($row=mysqli_fetch_assoc($result)){
            if($rowcount>0){
                $jor_num = $row['jor_num'];
                $requested_by = $row['requested_by'];
                $dept_name = $row['dept_name'];
                $requested_to = $row['requested_to'];
                $jor_title = $row['jor_title'];
                $jor_description = $row['jor_description'];
                $order_date = $row['order_date'];
                $status = $row['status'];
                $date = date_create($order_date);
                echo"<tr>
                    <td>".$jor_num."</td>
                    <td>".$requested_by."</td>
                    <td>".$requested_to."</td>
                    <td>".$jor_title."</td>
                    <td>".date_format($date, "F d, Y / g:ia")."</td>
                    <td>".$status."</td>
                </tr>";
            }else{
                echo"No result...";
            }
        }
    }

    function approve($id){
        global $connection;
        
		$query = "UPDATE request_form SET status = 'Approved' WHERE jor_num = ".$id;   
        $result = mysqli_query($connection, $query);
        
        
        if(!$result) {
          die("Database query failed.");
            
        }else{
            //echo("<meta http-equiv='refresh' content='1'>");
            
            $apprv_by = mysqli_real_escape_string($connection, $_GET['by']);
            $apprv_date = mysqli_real_escape_string($connection, $_GET['date']);
            $user_type = mysqli_real_escape_string($connection, $_GET['user']);
            
            var_dump($apprv_by);
            var_dump($apprv_date);
            var_dump($user_type);

//            $apprv_query = "INSERT INTO approved_tbl(apprv_by, apprv_date, jor_num) values ('{$apprv_by}', '{$apprv_date}', '{$id}')";
//
//            $apprv_result = mysqli_query($connection, $apprv_query);
//            if(!$apprv_result) {
//                die("Database query failed.");
        }       
    }
        

        

?>