<?php
    session_start();
    include("../includes/functions.php");
?>

<?php  
	session_destroy();
	$_SESSION["admin_usertype"] = null;
    $_SESSION["admin_deptname"] = null;
    $_SESSION["admin_username"] = null;
    $_SESSION["uhead_usertype"] = null;
    $_SESSION["uhead_deptname"] = null;
    $_SESSION["uhead_username"] = null;
	$_SESSION["staff_usertype"] = null;
    $_SESSION["staff_deptname"] = null;
    $_SESSION["staff_username"] = null;
    $_SESSION["dhead_usertype"] = null;
    $_SESSION["dhead_deptname"] = null;
    $_SESSION["dhead_username"] = null;

    redirect_to("../public/loginPage.php");
?>
