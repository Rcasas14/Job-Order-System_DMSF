<?php
	require("../includes/db_connection.php");
	include("../includes/functions.php");
?>

<!-- login -->
<?php

	if(isset($_POST['login'])) { 
		login();
	}
?>

<!-- request -->
<?php

	 if(isset($_POST['submit'])){
         if(isset($_GET['date'])){
             $date = $_GET['date'];
	 	     request($date);
         }
     }
?>

<!-- date range -->
<?php
	if(isset($_POST['search'])) {
        date_range();
	}
?>

<!-- approve -->
<?php
	if(isset($_GET['approve'])) {
        $id = $_GET['approve'];
//        approve($id);
	}
?>